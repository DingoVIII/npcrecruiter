import { redirect } from "next/navigation";

import { GuildmasterDashboard } from "@/components/admin/GuildmasterDashboard";
import { requireAdmin } from "@/lib/auth/requireAdmin";

export const dynamic = "force-dynamic";

export default async function GuildmasterDashboardPage() {
  const admin = await requireAdmin();

  if (!admin.authorized) {
    if (admin.status === 401) {
      redirect("/login");
    }

    redirect("/");
  }

  return <GuildmasterDashboard />;
}
